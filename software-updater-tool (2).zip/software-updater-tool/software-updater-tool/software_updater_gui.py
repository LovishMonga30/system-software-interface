import tkinter as tk
from tkinter import messagebox, simpledialog, scrolledtext
import subprocess
import datetime
import google.generativeai as genai
import getpass

# ─── Gemini AI Configuration ────────────────────────────────
genai.configure(api_key="AIzaSyCOcYYkkal5F59PTNAaJNjh8u-4B_JjIUU")
model = genai.GenerativeModel('models/gemini-pro')  # ✅ Corrected model name

sudo_password = ""

# ─── Sudo Password Prompt and Welcome Message ───────────────
def get_sudo_password():
    global sudo_password
    sudo_password = simpledialog.askstring("🔐 Sudo Password", "Enter your system password:", show='*')
    if not sudo_password:
        messagebox.showwarning("Cancelled", "Password is required.")
        root.quit()
    try:
        # Validate sudo permission
        subprocess.check_output(f'echo {sudo_password} | sudo -S -v', shell=True, stderr=subprocess.STDOUT)

        # ✅ Show welcome message with username
        username = getpass.getuser()
        messagebox.showinfo("👋 Welcome", f"Hey {username}, Welcome to the Software Updater Interface!")

    except subprocess.CalledProcessError:
        messagebox.showerror("❌ Sudo Error", "Incorrect password. Exiting.")
        root.quit()

# ─── Shell Command Runner ───────────────────────────────────
def run_command(command, use_sudo=False):
    try:
        if use_sudo:
            full_command = f'echo {sudo_password} | sudo -S bash -c "{command}"'
        else:
            full_command = command
        output = subprocess.check_output(full_command, shell=True, stderr=subprocess.STDOUT, text=True)
        show_output(f"$ {command}\n{output}")
    except subprocess.CalledProcessError as e:
        show_output(f"❌ Error running:\n{command}\n\n{e.output}")

# ─── Output Display ─────────────────────────────────────────
def show_output(text):
    output_text.config(state=tk.NORMAL)
    output_text.insert(tk.END, f"{text}\n{'='*60}\n")
    output_text.config(state=tk.DISABLED)
    output_text.see(tk.END)

# ─── Gemini AI Advice ───────────────────────────────────────
def get_gemini_advice():
    try:
        show_output("🔮 Asking Gemini AI for advice...")
        response = model.generate_content("Give a friendly Linux system maintenance tip.")
        show_output("💡 Gemini Says:\n" + response.text.strip())
    except Exception as e:
        show_output(f"Gemini Error: {e}")

# ─── Backup Installed Packages ──────────────────────────────
def backup_installed_packages():
    filename = f"installed_packages_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.list"
    run_command(f"dpkg --get-selections > {filename}")
    show_output(f"✅ Backup saved as {filename}")

# ─── Package Installation ───────────────────────────────────
def install_package():
    pkg = simpledialog.askstring("📦 Install Package", "Enter package name:")
    if pkg:
        run_command(f"apt install -y {pkg}", use_sudo=True)

# ─── GUI Setup ──────────────────────────────────────────────
root = tk.Tk()
root.title("🧠 Smart Software Updater Tool")
root.geometry("750x650")
root.configure(bg="#d0f0fd")  # Light sky blue

tk.Label(root, text="🔥 Choose an Action", font=("Arial", 18, "bold"), bg="#d0f0fd", fg="#007acc").pack(pady=12)

frame = tk.Frame(root, bg="#d0f0fd")
frame.pack(pady=5)

buttons = [
    ("1. Show System Info", lambda: run_command(
        "echo '🖥️ System:' && uname -a && "
        "echo '\n🧠 CPU:' && lscpu | grep 'Model name' && "
        "echo '\n💾 Memory:' && free -h && "
        "echo '\n🗂️ Disk Usage:' && df -h /"
    )),
    ("2. Update Packages", lambda: run_command("apt update", use_sudo=True)),
    ("3. Upgrade Packages", lambda: run_command("apt upgrade -y", use_sudo=True)),
    ("4. Clean Unused Packages", lambda: run_command("apt autoremove -y && apt clean", use_sudo=True)),
    ("5. Show Installed Package Count", lambda: run_command("dpkg -l | grep '^ii' | wc -l")),
    ("6. Dry Run Upgrade", lambda: run_command("apt upgrade --simulate", use_sudo=True)),
    ("7. Backup Installed Packages", backup_installed_packages),
    ("8. Install a Package", install_package),
    ("9. Exit", root.quit),
    ("10. Get Advice from Gemini", get_gemini_advice)
]

for text, cmd in buttons:
    tk.Button(frame, text=text, command=cmd, width=40, font=("Arial", 11, "bold"),
              bg="#a8ddf0", fg="black", activebackground="#87cbe0").pack(pady=5)

output_text = scrolledtext.ScrolledText(root, wrap=tk.WORD, height=15, state=tk.DISABLED,
                                        font=("Consolas", 10), bg="#f0faff", fg="black")
output_text.pack(pady=10, padx=15, fill=tk.BOTH, expand=True)

# Ask for sudo password after window loads
root.after(500, get_sudo_password)

root.mainloop()

