#!/bin/bash

# Colors
GREEN="\e[32m"
RED="\e[31m"
YELLOW="\e[33m"
CYAN="\e[36m"
NC="\e[0m" # No Color

# Log file
LOG_FILE="update_log.txt"

# Function: Show disk usage
show_disk_usage() {
    echo -e "${YELLOW}Disk Usage:${NC}"
    df -h /
    echo
}

# Function: Update packages
apt_update() {
    echo -e "${GREEN}🛠️ Updating package lists...${NC}"
    sudo apt update | tee -a "$LOG_FILE"
}

# Function: Upgrade packages
apt_upgrade() {
    echo -e "${GREEN}📦 Upgrading packages...${NC}"
    sudo apt upgrade -y | tee -a "$LOG_FILE"
}

# Function: Check Internet Connection
check_internet() {
    echo -e "${YELLOW}🌐 Checking internet connection...${NC}"
    if ping -c 1 google.com &> /dev/null; then
        echo -e "${GREEN}✅ You're online!${NC}"
    else
        echo -e "${RED}❌ No internet connection.${NC}"
    fi
}

# Function: Show battery info
show_battery() {
    echo -e "${YELLOW}🔋 Battery Status:${NC}"
    if command -v upower &> /dev/null; then
        BATTERY_PATH=$(upower -e | grep 'BAT')
        if [ -n "$BATTERY_PATH" ]; then
            upower -i "$BATTERY_PATH" | grep -E "state|percentage"
        else
            echo "🔌 No battery detected (desktop system?)"
        fi
    else
        echo "upower not installed. Try: sudo apt install upower"
    fi
    echo
}

# Function: Get advice (Gemini simulated)
call_gemini_real() {
    echo -e "${YELLOW}🔮 Gemini AI Advice:${NC}"
    echo -e "💡 Tip: Regularly update your packages and clean unused ones!"
    echo -e "🔥 Use 'apt upgrade --dry-run' to preview changes before running a big upgrade."
}

# Handle CLI argument
if [ "$1" ]; then
    choice=$1
    case $choice in
        1) show_battery ;;
        2) apt_update ;;
        3) apt_upgrade ;;
        4) check_internet ;;
        5) echo -e "${GREEN}Installed packages: $(dpkg -l | grep '^ii' | wc -l)${NC}" ;;
        6) echo -e "${GREEN}Running dry upgrade...${NC}"; sudo apt upgrade --dry-run | tee -a "$LOG_FILE" ;;
        7) dpkg --get-selections > installed_packages.list && echo -e "${GREEN}✅ Backup saved to installed_packages.list${NC}" ;;
        8) read -p "Enter package name: " pkg; sudo apt install "$pkg" | tee -a "$LOG_FILE" ;;
        9) echo -e "${RED}👋 Peace out!${NC}"; exit 0 ;;
        10) call_gemini_real ;;
        *) echo -e "${RED}Bruh... pick a valid option 😅${NC}" ;;
    esac
    exit 0
fi

# Fun header
clear
echo -e "${CYAN}🔥 Welcome to the Software Updater Tool 🔥${NC}"

# Main Menu
while true; do
    echo -e "\n${CYAN}🔥 What do you wanna do, boss? 🔥${NC}"
    echo "1. Show Battery Info"
    echo "2. Update Packages"
    echo "3. Upgrade Packages"
    echo "4. Check Internet Connection"
    echo "5. Show Installed Package Count"
    echo "6. Dry Run Upgrade"
    echo "7. Backup Installed Packages"
    echo "8. Install a Package"
    echo "9. Exit"
    echo "10. Get System Advice (Gemini AI)"

    read -p "Enter your choice (1-10): " choice

    case $choice in
        1) show_battery ;;
        2) apt_update ;;
        3) apt_upgrade ;;
        4) check_internet ;;
        5) echo -e "${GREEN}Installed packages: $(dpkg -l | grep '^ii' | wc -l)${NC}" ;;
        6) echo -e "${GREEN}Running dry upgrade...${NC}"; sudo apt upgrade --dry-run | tee -a "$LOG_FILE" ;;
        7) dpkg --get-selections > installed_packages.list && echo -e "${GREEN}✅ Backup saved to installed_packages.list${NC}" ;;
        8) read -p "Enter package name: " pkg; sudo apt install "$pkg" | tee -a "$LOG_FILE" ;;
        9) echo -e "${RED}👋 Peace out!${NC}"; break ;;
        10) call_gemini_real ;;
        *) echo -e "${RED}Bruh... pick a valid option 😅${NC}" ;;
    esac
done

